#include "datatype.h"
#include "function.h"

Student students[MAX];
int studentCount = 0;

const char *FILE_PATH = "hocsinh.bin";

void addStudent() {
    if (studentCount >= MAX) {
        printf("Danh sach sinh vien da day!\n");
        return;
    }
    printf("Nhap ma sinh vien: ");
    scanf("%9s", students[studentCount].studentId);
    getchar();
    printf("Nhap ten sinh vien: ");
    fgets(students[studentCount].name, sizeof(students[studentCount].name), stdin);
    strtok(students[studentCount].name, "\n");
    printf("Nhap ngay sinh (dd mm yyyy): ");
    scanf("%d %d %d", &students[studentCount].dateOfBirth.day, &students[studentCount].dateOfBirth.month, &students[studentCount].dateOfBirth.year);
    getchar();
    printf("Nhap gioi tinh (0: Nam, 1: Nu): ");
    scanf("%d", &students[studentCount].gender);
    getchar();
    printf("Nhap email: ");
    fgets(students[studentCount].email, sizeof(students[studentCount].email), stdin);
    strtok(students[studentCount].email, "\n");
    printf("Nhap so dien thoai: ");
    scanf("%19s", students[studentCount].phone);
    getchar();

    studentCount++;
    saveStudentsToFile();
    printf("\nSinh vien da duoc them thanh cong!\n");
}

void listStudents() {
    if (studentCount == 0) {
        printf("Khong co sinh vien nao!\n");
        return;
    }
    printf("\n============================================\n");
    printf("%-10s %-30s %-12s %-8s %-30s %-15s\n", "Ma SV", "Ten", "Ngay Sinh", "Gioi Tinh", "Email", "So DT");
    printf("============================================\n");
    for (int i = 0; i < studentCount; i++) {
        printf("%-10s %-30s %02d/%02d/%04d %-8s %-30s %-15s\n", 
               students[i].studentId, students[i].name, 
               students[i].dateOfBirth.day, students[i].dateOfBirth.month, students[i].dateOfBirth.year,
               students[i].gender == 0 ? "Nam" : "Nu", 
               students[i].email, students[i].phone);
    }
    printf("============================================\n");
}

void saveStudentsToFile() {
    FILE *file = fopen(FILE_PATH, "wb");
    if (file == NULL) {
        printf("Loi khi mo file!\n");
        return;
    }
    fwrite(students, sizeof(Student), studentCount, file);
    fclose(file);
    printf("Danh sach sinh vien da duoc luu vao file %s\n", FILE_PATH);
}

void loadStudentsFromFile() {
    FILE *file = fopen(FILE_PATH, "rb");
    if (file == NULL) {
        printf("Khong tim thay file danh sach sinh vien, tao danh sach moi.\n");
        return;
    }
    studentCount = fread(students, sizeof(Student), MAX, file);
    fclose(file);
    printf("Danh sach sinh vien da duoc nap thanh cong!\n");
}

