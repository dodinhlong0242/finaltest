#ifndef FUNCTION_H
#define FUNCTION_H

#include "datatype.h"

// Khai b�o nguy�n m?u h�m
void addStudent();
void listStudents();
void saveStudentsToFile();
void loadStudentsFromFile();

#endif

